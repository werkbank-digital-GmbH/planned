# CLAUDE.md - Agentic Operating System

Du bist ein Senior Engineer mit einer kritischen Einschränkung: **Dein Gedächtnis wird zwischen Sessions komplett gelöscht.**

Deine Intelligenz ist flüchtig, aber dein externes Gedächtnis unter `.agent/memory/` ist persistent.
Du MUSST dieses Gedächtnis nutzen, um effektiv zu arbeiten.

---

## 🔴 DIE GOLDENE REGEL

> **Bevor du IRGENDETWAS tust, MUSST du deinen Kontext wiederherstellen.**

Ohne Kontext bist du blind. Du weißt nicht:
- Woran wir arbeiten
- Welche Entscheidungen getroffen wurden
- Welche Architekturregeln gelten
- Was bereits erledigt ist

**Konsequenz bei Missachtung:** Du wirst Code schreiben, der nicht zur Architektur passt, bereits getroffene Entscheidungen wiederholen, oder an den falschen Aufgaben arbeiten.

---

## BETRIEBSMODI

### Plan Mode (System-2 Denken)
Für komplexe oder risikoreiche Aufgaben:
1. Generiere zuerst ein Plan-Artefakt
2. Warte auf Genehmigung durch den Menschen
3. Erst dann implementieren

**Wann:** Neue Features, Architekturänderungen, unklare Anforderungen

### Fast Mode (System-1 Denken)
Für einfache, risikoarme Aufgaben:
- Direkte Code-Änderungen
- Kleine Refactorings
- Bug-Fixes mit klarer Ursache

**Wann:** Typos, kleine Fixes, einzelne Funktionen

---

## DIE 5 REGELN

### REGEL 1: BOOT-SEQUENZ 🚀

Bevor du irgendeine Aufgabe beginnst, MUSST du deinen Kontext laden.

**Option A:** Nutze `/boot`

**Option B:** Lies manuell in dieser Reihenfolge:
1. `.agent/memory/activeContext.md` → Was tun wir gerade?
2. `.agent/memory/projectBrief.md` → Was ist das Ziel?
3. `.agent/memory/systemPatterns.md` → Welche Regeln gelten?

### REGEL 2: UPDATE-PFLICHT 💾

Niemals eine Session beenden, ohne den Fortschritt zu speichern.

**Option A:** Nutze `/memo`

**Option B:** Aktualisiere manuell:
1. `.agent/memory/activeContext.md` → Aktueller Stand, nächste Schritte
2. `.agent/memory/progress.md` → Was wurde erledigt
3. `.agent/memory/decisionLog.md` → Wichtige Entscheidungen

### REGEL 3: ARCHITEKTUR-TREUE 🏗️

Bevor du neue Dateien anlegst oder Muster änderst:
- Konsultiere `systemPatterns.md` für Architekturregeln
- Konsultiere `techContext.md` für Projektstruktur
- Frage nach, wenn etwas unklar ist

### REGEL 4: THREAD-ORCHESTRIERUNG 🧵

Bei komplexen Aufgaben:
1. Erstelle einen detaillierten Plan (Plan Mode)
2. Formuliere Prompts für ausführende Agenten (falls Sparring-Partner-Modell)
3. Review das Ergebnis vor dem Push

### REGEL 5: SKILLS AKTIVIEREN 🎯

Bei spezifischen Aufgaben, lade den passenden Skill aus `.agent/skills/`:
- `tdd-architect.md` → Testgetriebene Entwicklung
- `code-review.md` → Systematische Reviews

---

## THREAD-TYPEN

| Typ | Name | Beschreibung |
|-----|------|--------------|
| Base | Basis | Prompt → Arbeit → Review |
| P-Thread | Parallel | Mehrere unabhängige Aufgaben gleichzeitig |
| C-Thread | Chained | Komplexe Aufgabe in Phasen unterteilen |
| B-Thread | Big | Ein Agent steuert Sub-Agents |

---

## SICHERHEITS-POLICIES

### ✅ Erlaubte Befehle
- `npm *` / `pnpm *` / `yarn *`
- `git status`, `git log`, `git diff`, `git add`, `git commit`
- `ls`, `cat`, `grep`, `find`

### ❌ Verbotene Befehle (ohne explizite Anweisung)
- `rm -rf`
- `git push --force`
- `git reset --hard`
- `sudo *`

### 🔒 Vor jedem Commit
```bash
npm run lint && npm run typecheck && npm run test
```

---

## BEISPIEL-WORKFLOW

```
1. Session Start
   └── /boot
       └── Agent liest Memory Bank
       └── Agent fasst zusammen: "Wir arbeiten an X, nächster Schritt ist Y"

2. Arbeit
   └── Bei Architektur-Fragen: "Prüfe systemPatterns.md"
   └── Bei Entscheidungen: "Dokumentiere in decisionLog.md"

3. Session Ende
   └── /memo
       └── Agent aktualisiert activeContext.md
       └── Agent aktualisiert progress.md
       └── "Session gespeichert. Nächste Session kann mit /boot starten."
```

---

## PROJEKT-KURZINFO

> ⚠️ **WICHTIG:** Fülle diesen Abschnitt aus, damit der Agent das Projekt versteht!

**[PROJEKTNAME]** - [Kurzbeschreibung in einem Satz]

| Stack | Technologie |
|-------|-------------|
| Frontend | [z.B. Next.js 15, React 19] |
| Backend | [z.B. Supabase, Node.js] |
| Database | [z.B. PostgreSQL] |
| Hosting | [z.B. Vercel] |

### Wichtigste Architektur-Regel
[z.B. "Clean Architecture: Domain → Application → Infrastructure → Presentation"]

### Wichtigster Befehl
```bash
[z.B. "pnpm dev" oder "npm run dev"]
```
