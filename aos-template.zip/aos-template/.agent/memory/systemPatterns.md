# System Patterns

## Sicherheits-Guards

### Vor jedem Commit
```bash
# Anpassen an dein Projekt
npm run lint && npm run typecheck && npm run test
```

### Sensible Daten

- Niemals Secrets im Client-Code
- Umgebungsvariablen für API-Keys
- `.env` Dateien in `.gitignore`

---

## Architektur-Patterns

[Beschreibe die Architektur deines Projekts]

```
src/
├── [Ordner 1]/
├── [Ordner 2]/
└── [Ordner 3]/
```

---

## Naming Conventions

| Kontext | Convention | Beispiel |
|---------|------------|----------|
| Komponenten | PascalCase | `UserCard` |
| Funktionen | camelCase | `getUserById` |
| Konstanten | SCREAMING_SNAKE | `MAX_RETRIES` |
| Dateien | kebab-case | `user-service.ts` |

---

## Code-Patterns

[Dokumentiere hier die wichtigsten Patterns deines Projekts]

### Beispiel: Repository Pattern

```typescript
interface Repository<T> {
  findById(id: string): Promise<T | null>;
  save(entity: T): Promise<void>;
}
```
