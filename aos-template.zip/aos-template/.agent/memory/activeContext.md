# Active Context

## Aktueller Stand ([DATUM])

### Fokus

[Was ist die aktuelle Hauptaufgabe?]

### Laufende Arbeiten

- [Aufgabe 1]
- [Aufgabe 2]

### Nächste Schritte

- [ ] [Schritt 1]
- [ ] [Schritt 2]
- [ ] [Schritt 3]

### Offene Fragen

- [Frage 1]

---

## Letzte Session

**Datum:** [DATUM]

**Erledigt:**
- [Was wurde gemacht]

**Offen:**
- [Was noch zu tun ist]
