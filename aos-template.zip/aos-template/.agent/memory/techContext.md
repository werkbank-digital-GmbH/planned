# Technical Context

## Projektstruktur

```
[PROJEKTNAME]/
├── src/
│   └── [...]
├── tests/
├── public/
└── [Konfigurationsdateien]
```

## Wichtige Konfigurationsdateien

| Datei | Zweck |
|-------|-------|
| `package.json` | Dependencies, Scripts |
| `tsconfig.json` | TypeScript Konfiguration |
| `.env.local` | Lokale Umgebungsvariablen |

## Umgebungsvariablen

```env
# Beispiel - anpassen an dein Projekt
DATABASE_URL=
API_KEY=
```

## Scripts

```bash
# Development
npm run dev

# Build
npm run build

# Tests
npm run test

# Linting
npm run lint
```

## Dependencies (Kern)

```json
{
  "[framework]": "x.x",
  "[library]": "x.x"
}
```

## Deployment

- **Hosting**: [z.B. Vercel, AWS]
- **Database**: [z.B. Supabase, PlanetScale]
- **CI/CD**: [z.B. GitHub Actions]
