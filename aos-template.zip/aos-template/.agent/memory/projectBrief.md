# Project Brief: [PROJEKTNAME]

## Übersicht

[1-2 Sätze: Was ist das Projekt und was ist das Ziel?]

## Kernfunktionen

1. [Feature 1]
2. [Feature 2]
3. [Feature 3]

## Technologie-Stack

| Kategorie | Technologie |
|-----------|-------------|
| Frontend | [z.B. Next.js, React, Vue] |
| Backend | [z.B. Node.js, Supabase, Django] |
| Database | [z.B. PostgreSQL, MongoDB] |
| Hosting | [z.B. Vercel, AWS, Railway] |

## Architektur

[Kurze Beschreibung der Architektur, z.B. Monolith, Microservices, Clean Architecture]

## Zielgruppe

- [Wer nutzt das Produkt?]
- [In welchem Kontext?]

## Nicht-Ziele (Out of Scope)

- [Was wir NICHT bauen]
- [Bewusste Einschränkungen]
