# Product Context

## Das Problem

[Welches Problem lösen wir? Warum existiert dieses Projekt?]

1. **[Problem 1]**
   - [Beschreibung]

2. **[Problem 2]**
   - [Beschreibung]

## Die Lösung

[Wie löst das Projekt diese Probleme?]

## User Stories

### [Rolle 1, z.B. "Administrator"]

> Als [Rolle] möchte ich [Aktion], damit [Nutzen].

### [Rolle 2, z.B. "Endnutzer"]

> Als [Rolle] möchte ich [Aktion], damit [Nutzen].

## Nicht-Ziele (Out of Scope)

- **[Feature X]**: [Warum nicht]
- **[Feature Y]**: [Warum nicht]
