# Decision Log

Architekturentscheidungen mit Begründung, um Zyklen und Wiederholungen zu vermeiden.

---

## Template

```markdown
## YYYY-MM-DD: [Titel der Entscheidung]

**Kontext:** [Situation und Problem]

**Entscheidung:** [Was wurde entschieden]

**Begründung:** [Warum diese Entscheidung]

**Alternativen verworfen:**
- [Alternative 1] → [Grund]
- [Alternative 2] → [Grund]
```

---

## Beispiel

## 2024-XX-XX: [Framework] statt [Alternative]

**Kontext:** Wir brauchten eine Lösung für [Problem].

**Entscheidung:** Wir verwenden [Lösung].

**Begründung:**
- [Grund 1]
- [Grund 2]

**Alternativen verworfen:**
- [Alternative A] → [Warum nicht]
